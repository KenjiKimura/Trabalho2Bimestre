package br.univel.conexao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class Conexao {
	
	private static Conexao self;
	
	private Connection con;
	
	public static Connection conectaNoBanco(){
		String usuario = "postgres";
		String senha = "postgres";
		Connection con = null;
		
		try {
			Class.forName("org.postgresql.Driver");
			con = (Connection)DriverManager.getConnection("jdbc:postgresql://localhost:5432/trabalho", usuario, senha);
			System.out.println("Conex�o realizada com sucesso");
			return con;
			
		} catch (ClassNotFoundException ex) {
			System.out.println(ex.getMessage());
			return con;
		} catch (SQLException e) {
			System.out.println(e.getMessage());
			return con;
		}
	}
	
	public final static synchronized Conexao getInstance() {
		if(self == null){
			self = new Conexao();
		}
		return self;
	}
	
	public Connection getConnection(){
		return this.con;
	}
	
}
