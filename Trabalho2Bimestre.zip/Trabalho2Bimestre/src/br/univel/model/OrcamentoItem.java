package br.univel.model;

public class OrcamentoItem {
	
	private Integer orcamento_item_id;
	private Integer orcamento_id;
	private Integer produto_id;
	
	public Integer getOrcamento_item_id() {
		return orcamento_item_id;
	}
	public void setOrcamento_item_id(Integer orcamento_item_id) {
		this.orcamento_item_id = orcamento_item_id;
	}
	public Integer getOrcamento_id() {
		return orcamento_id;
	}
	public void setOrcamento_id(Integer orcamento_id) {
		this.orcamento_id = orcamento_id;
	}
	public Integer getProduto_id() {
		return produto_id;
	}
	public void setProduto_id(Integer produto_id) {
		this.produto_id = produto_id;
	}
	

}
