package br.univel.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

public class Orcamento implements Serializable{
	
	private Integer orcamentoId;
	private Integer codigoOrcamento;
	private Integer clienteId;
	private String nomeProduto;
	private BigDecimal preco;
	
	private List<OrcamentoItem> orcamentoItemList;
	
	public Integer getOrcamentoId() {
		return orcamentoId;
	}
	
	public void setOrcamentoId(Integer orcamentoId) {
		this.orcamentoId = orcamentoId;
	}
	
	public Integer getCodigoOrcamento() {
		return codigoOrcamento;
	}
	
	public void setCodigoOrcamento(Integer codigoOrcamento) {
		this.codigoOrcamento = codigoOrcamento;
	}
	
	public Integer getClienteId() {
		return clienteId;
	}
	
	public void setClienteId(Integer clienteId) {
		this.clienteId = clienteId;
	}
	
	public List<OrcamentoItem> getOrcamentoItemList() {
		return orcamentoItemList;
	}
	
	public void setOrcamentoItemList(List<OrcamentoItem> orcamentoItemList) {
		this.orcamentoItemList = orcamentoItemList;
	}

	public String getNomeProduto() {
		return nomeProduto;
	}

	public void setNomeProduto(String nomeProduto) {
		this.nomeProduto = nomeProduto;
	}

	public BigDecimal getPreco() {
		return preco;
	}

	public void setPreco(BigDecimal preco) {
		this.preco = preco;
	}
}
