package br.univel.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.univel.conexao.Conexao;
import br.univel.model.Orcamento;
import br.univel.model.OrcamentoItem;


public class OrcamentoItemDAO {
	
public List<OrcamentoItem> getTodosItensPorOrcamentoId(Integer orcamentoId){
		
		Connection con = Conexao.getInstance().getConnection();
		
		List<OrcamentoItem> OrcamentoItemList = new ArrayList<>();
		try (PreparedStatement ps = con.prepareStatement("SELECT * FROM orcamento_item WHERE orcamento_id = ?");
			ResultSet rs = ps.executeQuery()){
			
			while(rs.next()){
				OrcamentoItem oi = new OrcamentoItem();
				oi.setOrcamento_item_id(rs.getInt(1));
				oi.setOrcamento_id(rs.getInt(2));
				oi.setProduto_id(rs.getInt(3));
				OrcamentoItemList.add(oi);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return OrcamentoItemList;
	}

}
