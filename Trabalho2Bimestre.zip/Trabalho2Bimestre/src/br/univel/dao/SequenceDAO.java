package br.univel.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SequenceDAO {
	
	private String nameSequence;
	private Connection connection;
	
	public SequenceDAO(String nameSequence, Connection connection) {
		super();
		this.nameSequence = nameSequence;
		this.connection = connection;
	}
	
	public String getNameSequence() {
		return nameSequence;
	}
	
	public void setNameSequence(String nameSequence) {
		this.nameSequence = nameSequence;
	}

	public Integer getSequence(){
		int proximoNumeroSequencial = 0;
		String sql = "select nextval('"+ nameSequence +"')";
		PreparedStatement pst;
		try {
			pst = connection.prepareStatement(sql);
			ResultSet rs = pst.executeQuery();
			if(rs.next()){
		    	proximoNumeroSequencial = rs.getInt(1);
		    }
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return proximoNumeroSequencial;	
	}

}
