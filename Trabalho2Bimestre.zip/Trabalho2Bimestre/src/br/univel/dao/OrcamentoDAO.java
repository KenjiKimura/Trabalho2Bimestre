package br.univel.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.univel.conexao.Conexao;
import br.univel.model.Orcamento;


public class OrcamentoDAO {
	
public List<Orcamento> getTodos(){
		
		Connection con = Conexao.getInstance().getConnection();
		
		List<Orcamento> lista = new ArrayList<>();
		try(PreparedStatement ps = con.prepareStatement("SELECT * FROM orcamento");
			ResultSet rs = ps.executeQuery()){
			
			while(rs.next()){
				Orcamento o = new Orcamento();
				o.setOrcamentoId(rs.getInt(1));
				o.setNomeProduto(rs.getString(2));
				o.setPreco(rs.getBigDecimal(3));
				lista.add(o);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return lista;
	}

}
