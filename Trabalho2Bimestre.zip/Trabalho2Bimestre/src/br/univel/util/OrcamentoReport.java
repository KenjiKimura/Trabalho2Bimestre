package br.univel.util;

import java.util.Iterator;
import java.util.List;

import br.univel.model.Orcamento;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRField;

public class OrcamentoReport implements JRDataSource{
	
	private Iterator<Orcamento> it;
	private Orcamento selecionado;
	
	public OrcamentoReport(List<Orcamento> lista){
		this.it = lista.iterator();
	}
	
	@Override
	public boolean next() throws JRException {
		if (this.it.hasNext()){
			this.selecionado = it.next();
			return true;
		}
		return false;
	}
	

	@Override
	public Object getFieldValue(JRField field) throws JRException {
		
		if ("codigo do orcamento".equals(field.getName())){
			return selecionado.getOrcamentoId();
		}
		if ("codigo do produto".equals(field.getName())){
			return selecionado.getNomeProduto();
		}
		if ("pre�o".equals(field.getName())){
			return selecionado.getPreco();
		}
		throw new RuntimeException("...");
	}


}
