package br.univel.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import br.univel.model.Produto;

public class ReaderArquivo {

	List<Produto> lista = new ArrayList<>();
	
	public List<Produto> lerArquivo() {
		//ArrayList<String> lista = new ArrayList<>();

		try (FileReader fr = new FileReader(new File("02_07_2017_master10-com-py.txt"));
			BufferedReader br = new BufferedReader(fr)) {

			String linha = null;
			while ((linha = br.readLine()) != null) {
				if (linha.matches("[0-9]+.*")) {
					Produto p = lerProduto(linha);
					lista.add(p);
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return lista;
	}

	private Pattern pattern = Pattern.compile("([0-9]+)(.*)US\\$ (.*)");
	
	private Produto lerProduto(String linha) {
		
		Matcher mat = pattern.matcher(linha);
		
		Produto produto = new Produto();
		if (mat.matches()) {
			
			String strCodigo = mat.group(1).trim();
			produto.setCodigo(Integer.valueOf(strCodigo));
			
			String desc = mat.group(2).trim();
			produto.setNomeProduto(desc);
			
			String strValorOrginal = mat.group(3).trim();
			String strValorSemponto = strValorOrginal.replaceAll("\\.", "");
			String strValorIngles = strValorSemponto.replaceAll(",", ".");
			produto.setPreco(new BigDecimal(strValorIngles));
		} else {
			throw new RuntimeException("Linha inv�lida: " + linha);
		}
		return produto;
	}

}
