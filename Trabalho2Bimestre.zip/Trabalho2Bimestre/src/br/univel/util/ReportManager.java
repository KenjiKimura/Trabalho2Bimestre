package br.univel.util;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;



import br.univel.conexao.Conexao;
import br.univel.dao.OrcamentoDAO;
import br.univel.model.Orcamento;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.view.JasperViewer;

public class ReportManager {
	
	public void exportarCustom(){
		String strFile = "C:\\Users\\Kimura\\JaspersoftWorkspace\\MyReports\\Orcamento.jasper";
		
		OrcamentoDAO dao = new OrcamentoDAO();
		List<Orcamento> lista = dao.getTodos();
		
		JRDataSource customDs = new OrcamentoReport(lista);
		
		JasperPrint jp;
		try {
			jp = JasperFillManager.fillReport(strFile, null, customDs);
			JasperViewer.viewReport(jp, false);
		} catch (JRException e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		ReportManager rm = new ReportManager();
		rm.exportarCustom();
		
	}

}
