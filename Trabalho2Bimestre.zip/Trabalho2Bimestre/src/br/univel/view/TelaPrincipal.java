package br.univel.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import br.univel.conexao.Conexao;
import br.univel.dao.SequenceDAO;
import br.univel.adapter.ProdutoModel;
import br.univel.model.Produto;
import br.univel.util.ReaderArquivo;
import java.awt.GridBagLayout;
import javax.swing.JButton;
import java.awt.GridBagConstraints;
import javax.swing.JMenuBar;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JScrollPane;
import java.awt.Insets;
import javax.swing.JTable;

public class TelaPrincipal extends JFrame {

	private JPanel contentPane;
	private JTable table;
	
	private static Connection con;
	private static PreparedStatement pst;
	private ResultSet resultado;
	
	private JMenu mnCadastroDeClientes;
	private JMenuItem mntmCadastroDeClientes;
	private JMenuItem mntmCadastroDeOrcamento;
	
	private JButton btnImportar;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelaPrincipal frame = new TelaPrincipal();
					frame.setVisible(true);
					con = Conexao.conectaNoBanco();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TelaPrincipal() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 350);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		mnCadastroDeClientes = new JMenu("Menus");
		menuBar.add(mnCadastroDeClientes);
		
		mntmCadastroDeClientes = new JMenuItem("Cadastro de clientes");
		mnCadastroDeClientes.add(mntmCadastroDeClientes);
		mntmCadastroDeClientes.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				FecharFrame();
				CadastroCliente frameCliente = new CadastroCliente();
				frameCliente.setVisible(true);
			}
		});
		
		mntmCadastroDeOrcamento = new JMenuItem("Cadastro de or\u00E7amentos");
		mnCadastroDeClientes.add(mntmCadastroDeOrcamento);
		mntmCadastroDeOrcamento.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
			FecharFrame();
			CadastroOrcamento frameOrcamento = new CadastroOrcamento();
			frameOrcamento.setVisible(true);
				
			}
		});
		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);
		GridBagLayout gbl_panel = new GridBagLayout();
		gbl_panel.columnWidths = new int[]{0, 0};
		gbl_panel.rowHeights = new int[]{0, 0, 0, 0, 0, 0};
		gbl_panel.columnWeights = new double[]{1.0, Double.MIN_VALUE};
		gbl_panel.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 1.0, Double.MIN_VALUE};
		panel.setLayout(gbl_panel);
		
		btnImportar = new JButton("Importar");
		btnImportar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ReaderArquivo arq = new ReaderArquivo();
				List<Produto> lista = arq.lerArquivo();//1 ler o arquivo
				
				for (int i = 0; i < lista.size(); i++) {//2 gravar no banco
					Produto p = lista.get(i);
					//salvar(p);
				}
				
				buscarTodos();// 3 pegar do banco e jogar na tela
			}
		});
		
		
		
		GridBagConstraints gbc_btnImportar = new GridBagConstraints();
		gbc_btnImportar.insets = new Insets(0, 0, 5, 0);
		gbc_btnImportar.gridx = 0;
		gbc_btnImportar.gridy = 0;
		panel.add(btnImportar, gbc_btnImportar);
		
		JScrollPane scrollPane = new JScrollPane();
		GridBagConstraints gbc_scrollPane = new GridBagConstraints();
		gbc_scrollPane.gridheight = 4;
		gbc_scrollPane.fill = GridBagConstraints.BOTH;
		gbc_scrollPane.gridx = 0;
		gbc_scrollPane.gridy = 1;
		panel.add(scrollPane, gbc_scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
	}
	
	public void salvar(Produto produto){
		String sql = "INSERT INTO produto VALUES (?, ?, ?, ?)";
		
		try {
			pst = con.prepareStatement(sql);
			pst.setInt(1, new SequenceDAO("PRODUTO_SEQ", con).getSequence());
			pst.setInt(2, produto.getCodigo());
			pst.setString(3, produto.getNomeProduto());
			pst.setObject(4, produto.getPreco());
			
			pst.execute();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}
	
	public void buscarTodos(){
		List<Produto> listaProdutos = new ArrayList<>();
		String sql = "SELECT * FROM produto";
		
		try {
			pst = con.prepareStatement(sql);
			resultado = pst.executeQuery();
			while(resultado.next()){
				
				Produto produto = new Produto();
				produto.setProdutoId(Integer.valueOf(resultado.getInt("produto_id")));
				produto.setCodigo(resultado.getInt("codigo"));
				produto.setNomeProduto(resultado.getString("nome_produto"));
				produto.setPreco(resultado.getBigDecimal("preco"));
				
				listaProdutos.add(produto);
				
				ProdutoModel pm = new ProdutoModel();
				pm.setListaDeProdutos(listaProdutos);
				table.setModel(pm);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	
	
	private void FecharFrame(){
		super.dispose();
	}


}
