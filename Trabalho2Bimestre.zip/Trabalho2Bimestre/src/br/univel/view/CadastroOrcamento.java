package br.univel.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import br.univel.adapter.OrcamentoModel;
import br.univel.adapter.ProdutoModel;
import br.univel.conexao.Conexao;
import br.univel.dao.SequenceDAO;
import br.univel.model.Orcamento;
import br.univel.model.Produto;
import br.univel.util.ReaderArquivo;

import java.awt.GridBagLayout;
import javax.swing.JLabel;
import java.awt.GridBagConstraints;
import javax.swing.JTextField;
import java.awt.Insets;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.Dimension;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

public class CadastroOrcamento extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JMenuItem mntmCadastroDeProduto;
	private JMenuItem mntmCadastroDeClientes;
	private JMenuItem mntmImprimirPdf;
	
	private static Connection con;
	private static PreparedStatement pst;
	private ResultSet resultado;
	private String produtoDeletado;
	private JMenuItem mntmCatlogoDeProdutos;
	private JTextField textField;

	/**
	 * Create the frame.
	 */
	public CadastroOrcamento() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 359);
		
		con = Conexao.conectaNoBanco();
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnMenus = new JMenu("Menus");
		menuBar.add(mnMenus);
		
		mntmCadastroDeProduto = new JMenuItem("Cadastro de produto");
		mnMenus.add(mntmCadastroDeProduto);
		mntmCadastroDeProduto.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				FecharFrame();
				TelaPrincipal frameProduto = new TelaPrincipal();
				frameProduto.setVisible(true);
				
				
			}
		});
		
		mntmCadastroDeClientes = new JMenuItem("Cadastro de clientes");
		mnMenus.add(mntmCadastroDeClientes);
		mntmCadastroDeClientes.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				FecharFrame();
				CadastroCliente frameCliente = new CadastroCliente();
				frameCliente.setVisible(true);
				
			}
		});
		
		JMenu mnArquivo = new JMenu("Arquivo");
		menuBar.add(mnArquivo);
		
		mntmImprimirPdf = new JMenuItem("Imprimir PDF n�o est� funcionando");
		mnArquivo.add(mntmImprimirPdf);
		mntmImprimirPdf.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println(":(");
			}
		});
		
		JMenu mnCatlogo = new JMenu("Cat\u00E1logo");
		menuBar.add(mnCatlogo);
		
		mntmCatlogoDeProdutos = new JMenuItem("Cat\u00E1logo de produtos");
		mnCatlogo.add(mntmCatlogoDeProdutos);
		mntmCatlogoDeProdutos.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				PainelCatalogo frameCatalogo = new PainelCatalogo();
				frameCatalogo.setVisible(true);
				
			}
		});
		
		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);
		GridBagLayout gbl_panel = new GridBagLayout();
		gbl_panel.columnWidths = new int[]{0, 0, 0, 0};
		gbl_panel.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0};
		gbl_panel.columnWeights = new double[]{0.0, 0.0, 1.0, Double.MIN_VALUE};
		gbl_panel.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, Double.MIN_VALUE};
		panel.setLayout(gbl_panel);
		
		JButton btnAcrecentarItem = new JButton("Carregar/Atualizar Lista");
		btnAcrecentarItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				buscarTodos();
			}
		});
		
		JLabel lblDeletarItemN = new JLabel("Deletar item N\u00BA:");
		GridBagConstraints gbc_lblDeletarItemN = new GridBagConstraints();
		gbc_lblDeletarItemN.insets = new Insets(0, 0, 5, 5);
		gbc_lblDeletarItemN.gridx = 0;
		gbc_lblDeletarItemN.gridy = 0;
		panel.add(lblDeletarItemN, gbc_lblDeletarItemN);
		
		textField = new JTextField();
		GridBagConstraints gbc_textField = new GridBagConstraints();
		gbc_textField.gridwidth = 2;
		gbc_textField.insets = new Insets(0, 0, 5, 0);
		gbc_textField.fill = GridBagConstraints.HORIZONTAL;
		gbc_textField.gridx = 1;
		gbc_textField.gridy = 0;
		panel.add(textField, gbc_textField);
		textField.setColumns(10);
		
		JButton btnDeletarItem = new JButton("Deletar Item");
		btnDeletarItem.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				produtoDeletado = textField.getText();
				excluir();
				buscarTodos();
				
			}
		});
		GridBagConstraints gbc_btnDeletarItem = new GridBagConstraints();
		gbc_btnDeletarItem.anchor = GridBagConstraints.WEST;
		gbc_btnDeletarItem.gridwidth = 3;
		gbc_btnDeletarItem.insets = new Insets(0, 0, 5, 0);
		gbc_btnDeletarItem.gridx = 0;
		gbc_btnDeletarItem.gridy = 1;
		panel.add(btnDeletarItem, gbc_btnDeletarItem);
		GridBagConstraints gbc_btnAcrecentarItem = new GridBagConstraints();
		gbc_btnAcrecentarItem.gridwidth = 3;
		gbc_btnAcrecentarItem.insets = new Insets(0, 0, 5, 0);
		gbc_btnAcrecentarItem.gridx = 0;
		gbc_btnAcrecentarItem.gridy = 2;
		panel.add(btnAcrecentarItem, gbc_btnAcrecentarItem);
		
		JLabel lblFavorPreencherA = new JLabel("FAVOR: PREENCHER A LISTA ANTES DE CARREGA-LA");
		GridBagConstraints gbc_lblFavorPreencherA = new GridBagConstraints();
		gbc_lblFavorPreencherA.gridwidth = 3;
		gbc_lblFavorPreencherA.insets = new Insets(0, 0, 5, 0);
		gbc_lblFavorPreencherA.gridx = 0;
		gbc_lblFavorPreencherA.gridy = 3;
		panel.add(lblFavorPreencherA, gbc_lblFavorPreencherA);
		
		JScrollPane scrollPane = new JScrollPane();
		GridBagConstraints gbc_scrollPane = new GridBagConstraints();
		gbc_scrollPane.gridwidth = 3;
		gbc_scrollPane.gridheight = 3;
		gbc_scrollPane.fill = GridBagConstraints.BOTH;
		gbc_scrollPane.gridx = 0;
		gbc_scrollPane.gridy = 4;
		panel.add(scrollPane, gbc_scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
	}


	public void buscarTodos(){
		String sql = "SELECT * FROM orcamento";
		List<Orcamento> listaOrcamentos = new ArrayList<>();
		
		try {
			pst = con.prepareStatement(sql);
			
			resultado = pst.executeQuery();
			while(resultado.next()){
				Orcamento orcamento = new Orcamento();
				orcamento.setOrcamentoId(Integer.valueOf(resultado.getInt("orcamento_id")));
				orcamento.setNomeProduto(resultado.getString("nome_produto"));
				orcamento.setPreco(resultado.getBigDecimal("preco_orcamento"));
				
				
				listaOrcamentos.add(orcamento);
				
				OrcamentoModel om = new OrcamentoModel();
				om.setListaDeOrcamentos(listaOrcamentos);
				table.setModel(om);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	private void excluir() {
		String sql = "DELETE FROM orcamento WHERE orcamento_id = ?";
		try {
			pst = con.prepareStatement(sql);
			pst.setInt(1,(Integer.parseInt(produtoDeletado)));
			pst.execute();
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}

	protected void FecharFrame() {
		super.dispose();
		
	}


}
