package br.univel.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import br.univel.adapter.ClienteModel;
import br.univel.adapter.ProdutoModel;
import br.univel.conexao.Conexao;
import br.univel.dao.SequenceDAO;
import br.univel.model.Cliente;
import br.univel.model.Produto;

import java.awt.GridBagLayout;
import javax.swing.JLabel;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JTextField;
import java.awt.Dimension;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JButton;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

public class BuscaCliente extends JFrame {

	private JPanel contentPane;
	private JTextField textField_1;
	private JTable table;

	private static Connection con;
	private static PreparedStatement pst;
	private ResultSet resultado;
	private JMenuItem mntmVoltarAoCadastro;
	
	/**
	 * Create the frame.
	 */
	public BuscaCliente() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 350);
		
		con = Conexao.conectaNoBanco();
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnMenu = new JMenu("Menu");
		menuBar.add(mnMenu);
		
		mntmVoltarAoCadastro = new JMenuItem("Voltar ao cadastro");
		mnMenu.add(mntmVoltarAoCadastro);
		mntmVoltarAoCadastro.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				FecharFrame();
				CadastroCliente frameCliente = new CadastroCliente();
				frameCliente.setVisible(true);
				
			}
		});
		
		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);
		GridBagLayout gbl_panel = new GridBagLayout();
		gbl_panel.columnWidths = new int[]{0, 0, 0};
		gbl_panel.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0};
		gbl_panel.columnWeights = new double[]{0.0, 1.0, Double.MIN_VALUE};
		gbl_panel.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 1.0, Double.MIN_VALUE};
		panel.setLayout(gbl_panel);
		
		JLabel lblNome = new JLabel("Nome");
		GridBagConstraints gbc_lblNome = new GridBagConstraints();
		gbc_lblNome.anchor = GridBagConstraints.EAST;
		gbc_lblNome.insets = new Insets(0, 0, 5, 5);
		gbc_lblNome.gridx = 0;
		gbc_lblNome.gridy = 0;
		panel.add(lblNome, gbc_lblNome);
		
		textField_1 = new JTextField();
		GridBagConstraints gbc_textField_1 = new GridBagConstraints();
		gbc_textField_1.insets = new Insets(0, 0, 5, 0);
		gbc_textField_1.fill = GridBagConstraints.HORIZONTAL;
		gbc_textField_1.gridx = 1;
		gbc_textField_1.gridy = 0;
		panel.add(textField_1, gbc_textField_1);
		textField_1.setColumns(10);
		
		JButton btnBuscar = new JButton("Buscar");
		btnBuscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (textField_1.getText() != null && !textField_1.getText().equals("")){
					buscarClientes(textField_1.getText().toUpperCase());
				} else {
					buscarTodos();
				}
			}
		});
		GridBagConstraints gbc_btnBuscar = new GridBagConstraints();
		gbc_btnBuscar.anchor = GridBagConstraints.EAST;
		gbc_btnBuscar.insets = new Insets(0, 0, 5, 0);
		gbc_btnBuscar.gridx = 1;
		gbc_btnBuscar.gridy = 1;
		panel.add(btnBuscar, gbc_btnBuscar);
		
		JButton button = new JButton("New button");
		GridBagConstraints gbc_button = new GridBagConstraints();
		gbc_button.insets = new Insets(0, 0, 5, 0);
		gbc_button.gridx = 1;
		gbc_button.gridy = 2;
		panel.add(button, gbc_button);
		
		JScrollPane scrollPane = new JScrollPane();
		GridBagConstraints gbc_scrollPane = new GridBagConstraints();
		gbc_scrollPane.gridwidth = 2;
		gbc_scrollPane.gridheight = 3;
		gbc_scrollPane.fill = GridBagConstraints.BOTH;
		gbc_scrollPane.gridx = 0;
		gbc_scrollPane.gridy = 3;
		panel.add(scrollPane, gbc_scrollPane);
		
		table = new JTable();
		scrollPane.setRowHeaderView(table);
	}
	
	public void salvar(Cliente cliente){
		String sql = "INSERT INTO cliente VALUES (?, ?, ?)";
		
		try {
			pst = con.prepareStatement(sql);
			pst.setInt(1, cliente.getClienteId());
			pst.setString(2, cliente.getNome());
			pst.setString(3, cliente.getCpf());
			
			pst.execute();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}
	
	public void buscarTodos(){
		String sql = "SELECT * FROM cliente";
		List<Cliente> listaClientes = new ArrayList<>();
		
		try {
			pst = con.prepareStatement(sql);
			
			resultado = pst.executeQuery();
			while(resultado.next()){
				Cliente cliente = new Cliente();
				cliente.setClienteId(resultado.getInt("cliente_id"));
				cliente.setNome(resultado.getString("nome"));
				cliente.setCpf(resultado.getString("cpf"));
				
				listaClientes.add(cliente);
				
				ClienteModel cm = new ClienteModel();
				cm.setListaDeClientes(listaClientes);
				table.setModel(cm);
				
				//so um exemplo
				int posicao = table.getSelectedRow();
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	public void buscarClientes(String nome){
		String sql = "SELECT * FROM cliente WHERE nome = ?";
		List<Cliente> listaClientes = new ArrayList<>();
		
		try {
			
			pst = con.prepareStatement(sql);
			pst.setString(1, nome);
			resultado = pst.executeQuery();
			
			while(resultado.next()){
				Cliente cliente = new Cliente();
				cliente.setClienteId(resultado.getInt("cliente_id"));
				cliente.setNome(resultado.getString("nome"));
				cliente.setCpf(resultado.getString("cpf"));
				
				listaClientes.add(cliente);
				
				ClienteModel cm = new ClienteModel();
				cm.setListaDeClientes(listaClientes);
				table.setModel(cm);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

	protected void FecharFrame() {
		super.dispose();
		
	}

}
