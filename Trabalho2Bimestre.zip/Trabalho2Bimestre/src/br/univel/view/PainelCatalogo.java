package br.univel.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import br.univel.adapter.ProdutoModel;
import br.univel.conexao.Conexao;
import br.univel.dao.SequenceDAO;
import br.univel.model.Cliente;
import br.univel.model.Orcamento;
import br.univel.model.Produto;

import java.awt.GridBagLayout;
import javax.swing.JScrollPane;
import java.awt.GridBagConstraints;
import javax.swing.JButton;
import java.awt.Insets;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import javax.swing.JTextField;

public class PainelCatalogo extends JFrame {

	private static Connection con;
	private static PreparedStatement pst;
	private ResultSet resultado;
	
	private JPanel contentPane;
	private JTable tableCatalogo;
	protected int colunaSelecionada;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Create the frame.
	 */
	public PainelCatalogo() {
		
		con = Conexao.conectaNoBanco();
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 495, 459);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gbl_contentPane.rowHeights = new int[]{0, 0, 0, 0, 0, 0};
		gbl_contentPane.columnWeights = new double[]{1.0, 0.0, 1.0, 1.0, 0.0, 1.0, 0.0, 0.0, 1.0, Double.MIN_VALUE};
		gbl_contentPane.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 1.0, Double.MIN_VALUE};
		contentPane.setLayout(gbl_contentPane);
		
		JButton btnFecharCatalogo = new JButton("Fechar Catalogo");
		btnFecharCatalogo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				FecharPainel();
			}
		});
		
		JLabel lblNomeDoProduto = new JLabel("Produto:");
		GridBagConstraints gbc_lblNomeDoProduto = new GridBagConstraints();
		gbc_lblNomeDoProduto.gridwidth = 4;
		gbc_lblNomeDoProduto.anchor = GridBagConstraints.EAST;
		gbc_lblNomeDoProduto.insets = new Insets(0, 0, 5, 5);
		gbc_lblNomeDoProduto.gridx = 0;
		gbc_lblNomeDoProduto.gridy = 0;
		contentPane.add(lblNomeDoProduto, gbc_lblNomeDoProduto);
		
		textField = new JTextField();
		GridBagConstraints gbc_textField = new GridBagConstraints();
		gbc_textField.gridwidth = 9;
		gbc_textField.insets = new Insets(0, 0, 5, 5);
		gbc_textField.fill = GridBagConstraints.HORIZONTAL;
		gbc_textField.gridx = 4;
		gbc_textField.gridy = 0;
		contentPane.add(textField, gbc_textField);
		textField.setColumns(10);
		
		JLabel lblPreo = new JLabel("Pre\u00E7o:");
		GridBagConstraints gbc_lblPreo = new GridBagConstraints();
		gbc_lblPreo.gridwidth = 4;
		gbc_lblPreo.anchor = GridBagConstraints.EAST;
		gbc_lblPreo.insets = new Insets(0, 0, 5, 5);
		gbc_lblPreo.gridx = 0;
		gbc_lblPreo.gridy = 1;
		contentPane.add(lblPreo, gbc_lblPreo);
		
		textField_1 = new JTextField();
		GridBagConstraints gbc_textField_1 = new GridBagConstraints();
		gbc_textField_1.gridwidth = 4;
		gbc_textField_1.insets = new Insets(0, 0, 5, 5);
		gbc_textField_1.fill = GridBagConstraints.HORIZONTAL;
		gbc_textField_1.gridx = 4;
		gbc_textField_1.gridy = 1;
		contentPane.add(textField_1, gbc_textField_1);
		textField_1.setColumns(10);
		
		JLabel lblFavorUtilizarPonto = new JLabel("FAVOR UTILIZAR PONTO NO PRE\u00C7O");
		GridBagConstraints gbc_lblFavorUtilizarPonto = new GridBagConstraints();
		gbc_lblFavorUtilizarPonto.insets = new Insets(0, 0, 5, 5);
		gbc_lblFavorUtilizarPonto.gridx = 6;
		gbc_lblFavorUtilizarPonto.gridy = 2;
		contentPane.add(lblFavorUtilizarPonto, gbc_lblFavorUtilizarPonto);
		GridBagConstraints gbc_btnFecharCatalogo = new GridBagConstraints();
		gbc_btnFecharCatalogo.gridwidth = 6;
		gbc_btnFecharCatalogo.insets = new Insets(0, 0, 5, 5);
		gbc_btnFecharCatalogo.gridx = 0;
		gbc_btnFecharCatalogo.gridy = 3;
		contentPane.add(btnFecharCatalogo, gbc_btnFecharCatalogo);
		
		JButton btnAdicionarAoCarrinho = new JButton("Adicionar ao carrinho");
		btnAdicionarAoCarrinho.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Produto p = new Produto();
				p.setProdutoId(new SequenceDAO("ORCAMENTO_SEQ", con).getSequence());
				p.setNomeProduto(textField.getText());
				p.setPreco(new BigDecimal(textField_1.getText()));
				if (textField_1.getText() != null && !textField_1.getText().equals("")){
					AdicionarNoCarrinho(p);
				} else{
					JOptionPane.showMessageDialog(null, "O campo de produto n�o deve estar vazio");
				}
			}
		});
		GridBagConstraints gbc_btnAdicionarAoCarrinho = new GridBagConstraints();
		gbc_btnAdicionarAoCarrinho.anchor = GridBagConstraints.EAST;
		gbc_btnAdicionarAoCarrinho.gridwidth = 7;
		gbc_btnAdicionarAoCarrinho.insets = new Insets(0, 0, 5, 5);
		gbc_btnAdicionarAoCarrinho.gridx = 6;
		gbc_btnAdicionarAoCarrinho.gridy = 3;
		contentPane.add(btnAdicionarAoCarrinho, gbc_btnAdicionarAoCarrinho);
		
		JScrollPane scrollPane = new JScrollPane();
		GridBagConstraints gbc_scrollPane = new GridBagConstraints();
		gbc_scrollPane.gridwidth = 13;
		gbc_scrollPane.fill = GridBagConstraints.BOTH;
		gbc_scrollPane.gridx = 0;
		gbc_scrollPane.gridy = 4;
		contentPane.add(scrollPane, gbc_scrollPane);
		
		tableCatalogo = new JTable();
		scrollPane.setViewportView(tableCatalogo);
		
		buscarTodos();
		
		colunaSelecionada = tableCatalogo.getSelectedRow();
		
	}
	
	protected void AdicionarNoCarrinho(Produto produto) {
		String sql = "INSERT INTO orcamento VALUES (?, ?, ?)";
		
		try {
			pst = con.prepareStatement(sql);
			pst.setInt(1, produto.getProdutoId());
			pst.setString(2, produto.getNomeProduto());
			pst.setObject(3, produto.getPreco());
			
			pst.execute();
			System.out.println("Item adicionado ao carrinho");
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}

	private void FecharPainel(){
		super.dispose();
	}
	
	public void buscarTodos(){
		List<Produto> listaProdutos = new ArrayList<>();
		String sql = "SELECT * FROM produto";
		
		try {
			pst = con.prepareStatement(sql);
			resultado = pst.executeQuery();
			while(resultado.next()){
				
				Produto produto = new Produto();
				produto.setProdutoId(Integer.valueOf(resultado.getInt("produto_id")));
				produto.setCodigo(resultado.getInt("codigo"));
				produto.setNomeProduto(resultado.getString("nome_produto"));
				produto.setPreco(resultado.getBigDecimal("preco"));
				
				listaProdutos.add(produto);
				
				ProdutoModel pm = new ProdutoModel();
				pm.setListaDeProdutos(listaProdutos);
				tableCatalogo.setModel(pm);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

}
