package br.univel.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import br.univel.adapter.ClienteModel;
import br.univel.adapter.ProdutoModel;
import br.univel.conexao.Conexao;
import br.univel.dao.SequenceDAO;
import br.univel.model.Cliente;
import br.univel.model.Produto;

import java.awt.GridBagLayout;
import javax.swing.JLabel;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JTextField;
import java.awt.Dimension;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JButton;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

public class CadastroCliente extends JFrame {

	private JPanel contentPane;
	private JTextField textField_1;
	private JTable table;
	private JMenu mnMenus;
	private JMenuItem mntmCadastroDeProdutos;
	private JMenuItem mntmCadastroDeOrcamento;

	private static Connection con;
	private static PreparedStatement pst;
	private ResultSet resultado;
	private JMenuItem mntmBuscarClientef;
	private JTextField textField_2;
	
	/**
	 * Create the frame.
	 */
	public CadastroCliente() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 350);
		
		con = Conexao.conectaNoBanco();
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		mnMenus = new JMenu("Menus");
		menuBar.add(mnMenus);
		
		mntmCadastroDeOrcamento = new JMenuItem("Cadastro de or\u00E7amento");
		mnMenus.add(mntmCadastroDeOrcamento);
		mntmCadastroDeOrcamento.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				FecharFrame();
				CadastroOrcamento frameOrcamento = new CadastroOrcamento();
				frameOrcamento.setVisible(true);
				
				
			}
		});
		
		mntmCadastroDeProdutos = new JMenuItem("Cadastro de produtos");
		mnMenus.add(mntmCadastroDeProdutos);
		mntmCadastroDeProdutos.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				FecharFrame();
				TelaPrincipal frameProduto = new TelaPrincipal();
				frameProduto.setVisible(true);
				
				
			}
		});
		
		JMenu mnTelas = new JMenu("Telas");
		menuBar.add(mnTelas);
		
		mntmBuscarClientef = new JMenuItem("Buscar Cliente (F2)");
		mnTelas.add(mntmBuscarClientef);
		mntmBuscarClientef.addKeyListener(new KeyAdapter() {
			    public void keyPressed(java.awt.event.KeyEvent evt) {
			      if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
			    	  FecharFrame();
					  BuscaCliente frameBusca = new BuscaCliente();
					  frameBusca.setVisible(true);
						
			    }
			   }
			 });
		
		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);
		GridBagLayout gbl_panel = new GridBagLayout();
		gbl_panel.columnWidths = new int[]{0, 0, 0};
		gbl_panel.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0};
		gbl_panel.columnWeights = new double[]{0.0, 1.0, Double.MIN_VALUE};
		gbl_panel.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 1.0, Double.MIN_VALUE};
		panel.setLayout(gbl_panel);
		
		JLabel lblNome = new JLabel("Nome");
		GridBagConstraints gbc_lblNome = new GridBagConstraints();
		gbc_lblNome.anchor = GridBagConstraints.EAST;
		gbc_lblNome.insets = new Insets(0, 0, 5, 5);
		gbc_lblNome.gridx = 0;
		gbc_lblNome.gridy = 0;
		panel.add(lblNome, gbc_lblNome);
		
		textField_1 = new JTextField();
		GridBagConstraints gbc_textField_1 = new GridBagConstraints();
		gbc_textField_1.insets = new Insets(0, 0, 5, 0);
		gbc_textField_1.fill = GridBagConstraints.HORIZONTAL;
		gbc_textField_1.gridx = 1;
		gbc_textField_1.gridy = 0;
		panel.add(textField_1, gbc_textField_1);
		textField_1.setColumns(10);
		
		JLabel lblCpf = new JLabel("CPF");
		GridBagConstraints gbc_lblCpf = new GridBagConstraints();
		gbc_lblCpf.anchor = GridBagConstraints.EAST;
		gbc_lblCpf.insets = new Insets(0, 0, 5, 5);
		gbc_lblCpf.gridx = 0;
		gbc_lblCpf.gridy = 1;
		panel.add(lblCpf, gbc_lblCpf);
		
		JButton btnSalvar = new JButton("Salvar");
		btnSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Cliente c = new Cliente();
				c.setClienteId(new SequenceDAO("CLIENTE_SEQ", con).getSequence());
				c.setNome(textField_1.getText());
				c.setCpf(textField_2.getText());
				if (textField_1.getText() != null && !textField_1.getText().equals("")){
					salvar(c);
				} else {
					JOptionPane.showMessageDialog(null, "O campo de nome n�o deve estar vazio");
				}
				buscarTodos();
			}
		});
		
		textField_2 = new JTextField();
		textField_2.setPreferredSize(new Dimension(50, 20));
		textField_2.setMinimumSize(new Dimension(150, 20));
		GridBagConstraints gbc_textField_2 = new GridBagConstraints();
		gbc_textField_2.insets = new Insets(0, 0, 5, 0);
		gbc_textField_2.anchor = GridBagConstraints.WEST;
		gbc_textField_2.gridx = 1;
		gbc_textField_2.gridy = 1;
		panel.add(textField_2, gbc_textField_2);
		textField_2.setColumns(20);
		GridBagConstraints gbc_btnSalvar = new GridBagConstraints();
		gbc_btnSalvar.anchor = GridBagConstraints.EAST;
		gbc_btnSalvar.insets = new Insets(0, 0, 5, 0);
		gbc_btnSalvar.gridx = 1;
		gbc_btnSalvar.gridy = 3;
		panel.add(btnSalvar, gbc_btnSalvar);
		
		JScrollPane scrollPane = new JScrollPane();
		GridBagConstraints gbc_scrollPane = new GridBagConstraints();
		gbc_scrollPane.gridwidth = 2;
		gbc_scrollPane.gridheight = 2;
		gbc_scrollPane.fill = GridBagConstraints.BOTH;
		gbc_scrollPane.gridx = 0;
		gbc_scrollPane.gridy = 4;
		panel.add(scrollPane, gbc_scrollPane);
		
		table = new JTable();
		scrollPane.setRowHeaderView(table);
	}
	
	public void salvar(Cliente cliente){
		String sql = "INSERT INTO cliente VALUES (?, ?, ?)";
		
		try {
			pst = con.prepareStatement(sql);
			pst.setInt(1, cliente.getClienteId());
			pst.setString(2, cliente.getNome().toUpperCase());
			pst.setString(3, cliente.getCpf());
			
			pst.execute();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}
	
	public void buscarTodos(){
		String sql = "SELECT * FROM cliente";
		List<Cliente> listaClientes = new ArrayList<>();
		
		try {
			pst = con.prepareStatement(sql);
			
			resultado = pst.executeQuery();
			while(resultado.next()){
				Cliente cliente = new Cliente();
				cliente.setClienteId(resultado.getInt("cliente_id"));
				cliente.setNome(resultado.getString("nome"));
				cliente.setCpf(resultado.getString("cpf"));
				
				listaClientes.add(cliente);
				
				ClienteModel cm = new ClienteModel();
				cm.setListaDeClientes(listaClientes);
				table.setModel(cm);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

	protected void FecharFrame() {
		super.dispose();
		
	}

}
