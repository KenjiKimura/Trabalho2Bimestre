package br.univel.adapter;

import java.util.List;

import javax.swing.table.AbstractTableModel;

import br.univel.model.Orcamento;
import br.univel.model.Produto;

public class OrcamentoModel extends AbstractTableModel{

	List<Orcamento> listaDeOrcamentos;
	
	
	@Override
	public int getColumnCount() {
		return 3;
	}

	@Override
	public int getRowCount() {
		return listaDeOrcamentos.size();
	}

	@Override
	public Object getValueAt(int row, int column) {
		
		Orcamento o = this.listaDeOrcamentos.get(row);
		
		switch(column){
		case 0:
			return o.getOrcamentoId();
		case 1:
			return o.getNomeProduto();
		case 2:
			return o.getPreco();
		}
		return "...";
	}

	@Override
	public String getColumnName(int column) {
		switch(column){
		case 0:
			return "Codigo do orcamento";
		case 1:
			return "Id do cliente";
		case 2:
			return "Produto";
		}
		return super.getColumnName(column);
	}
	public List<Orcamento> getListaDeOrcamentos() {
		return listaDeOrcamentos;
	}

	public void setListaDeOrcamentos(List<Orcamento> listaDeOrcamentos) {
		this.listaDeOrcamentos = listaDeOrcamentos;
	}
}
