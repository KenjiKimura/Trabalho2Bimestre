package br.univel.adapter;

import java.util.List;

import javax.swing.table.AbstractTableModel;

import br.univel.model.Cliente;
import br.univel.model.Produto;

public class ClienteModel extends AbstractTableModel{

	List<Cliente> listaDeClientes;
	
	@Override
	public int getColumnCount() {
		return 3;
	}

	@Override
	public int getRowCount() {
		return listaDeClientes.size();
	}

	@Override
	public Object getValueAt(int row, int column) {
		
		Cliente c = this.listaDeClientes.get(row);
		
		switch (column){
		case 0:
			return c.getClienteId();
		case 1:
			return c.getNome();
		case 2:
			return c.getCpf();
		}
		return "...";
	}

	@Override
	public String getColumnName(int column) {

		switch (column){
		case 0:
			return "Id do cliente";
		case 1:
			return "Nome";
		case 2:
			return "Cpf";
		}
		return super.getColumnName(column);
	}
	public List<Cliente> getListaDeClientes() {
		return listaDeClientes;
	}

	public void setListaDeClientes(List<Cliente> listaDeClientes) {
		this.listaDeClientes = listaDeClientes;
	}
}
