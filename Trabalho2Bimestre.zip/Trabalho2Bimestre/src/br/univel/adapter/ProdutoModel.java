package br.univel.adapter;

import java.math.BigDecimal;
import java.util.List;

import javax.swing.table.AbstractTableModel;

import br.univel.model.Produto;

public class ProdutoModel extends AbstractTableModel{

	List<Produto> listaDeProdutos;
	
	@Override
	public int getColumnCount() {
		return 3;
	}

	@Override
	public int getRowCount() {
		return listaDeProdutos.size();
	}

	@Override
	public Object getValueAt(int row, int column) {
		

		Produto p = this.listaDeProdutos.get(row);
		
		switch (column) {
		case 0:
			return p.getCodigo();
		case 1:
			return p.getNomeProduto();
		case 2:
			return p.getPreco();
		}
		
		return "...";
	}
	
	public String getColumnName(int column) {
		switch (column) {
		case 0:
			return "Codigo";
		case 1:
			return "Descri��o";
		case 2:
			return "Pre�o";
		}
		return super.getColumnName(column);
	}

	public List<Produto> getListaDeProdutos() {
		return listaDeProdutos;
	}

	public void setListaDeProdutos(List<Produto> listaDeProdutos) {
		this.listaDeProdutos = listaDeProdutos;
	}
}
